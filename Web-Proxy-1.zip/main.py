import webbot,os,base64,time,replit,cursor
if os.path.exists("userpass.py"):
	os.remove("userpass.py")
	os.remove("Replacement.py")
	os.remove("Guest.py")
	os.remove("guestwrite.py")
web = webbot.Browser()
web.go_to("https://reddit.com/login/")
def Key_Tab(loop):
	loops=0
	while (loop!=loops):
		web.type(web.Key.TAB,into=input_elements[0].text)
		loops = loops + 1
input_elements = web.find_elements(xpath='//input')
Key_Tab(4)
web.type(base64.b64decode("yourusername").decode("utf-8"))
Key_Tab(1)
web.type(base64.b64decode("yourpassword").decode("utf-8"))
web.type(web.Key.ENTER,into=input_elements[0].text)
cursor.hide()
while True:
	print("Web Proxy Running \\")
	time.sleep(0.1)
	replit.clear()
	print("Web Proxy Running |")
	time.sleep(0.1)
	replit.clear()
	print("Web Proxy Running /")
	time.sleep(0.1)
	replit.clear()
	print("Web Proxy Running ─")
	time.sleep(0.1)
	replit.clear()